"use strict";

//dom event listener for button click event
document.getElementById("btn").addEventListener("click", function () {
  // alert('Button clicked!');
  var xmlhhtp = new XMLHttpRequest();
  console.log(xmlhhtp);
  console.log(xmlhhtp.readyState);
  console.log(xmlhhtp.status);
  xmlhhtp.onreadystatechange = function () {
    console.log(xmlhhtp.readyState, xmlhhtp.status);
    if (xmlhhtp.readyState === 4 && xmlhhtp.status === 200) {
      console.log(xmlhhtp.responseText);
      var result = JSON.parse(xmlhhtp.responseText);
      console.log(result);
      result &&
        result.length > 0 &&
        result.forEach(function (v, i) {
          console.log(v);
          console.log(i);
          var divtag = document.createElement("div");
          var imgtag = document.createElement("img");
          var h2tag = document.createElement("h2");
          var ptag = document.createElement("p");
          imgtag.src = v.image;
          h2tag.innerHTML = v.price;
          ptag.innerHTML = v.title;
          divtag.className = "col-3 text-center";
          imgtag.className = "img-fluid";
          divtag.append(imgtag, h2tag, ptag);
          document.querySelector("#row").append(divtag);
        });
    }
  };
  xmlhhtp.open("GET", "https://fakestoreapi.com/products");
  xmlhhtp.send();
});
