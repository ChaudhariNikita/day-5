"use strict";
document.getElementById("b1").onclick = function () {
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;

  var n1 = parseInt(data1);
  var n2 = parseInt(data2);
  var add = n1 + n2;

  document.getElementById("y1").innerHTML = add;
};

document.getElementById("b2").onclick = function () {
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;

  var n1 = parseInt(data1);
  var n2 = parseInt(data2);
  var sub = n1 - n2;

  document.getElementById("y1").innerHTML = sub;
};

document.getElementById("b3").onclick = function () {
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;

  var n1 = parseInt(data1);
  var n2 = parseInt(data2);
  var mul = n1 * n2;

  document.getElementById("y1").innerHTML = mul;
};

document.getElementById("b4").onclick = function () {
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;

  var n1 = parseInt(data1);
  var n2 = parseInt(data2);
  var div = n2 / n1;

  document.getElementById("y1").innerHTML = div;
};
