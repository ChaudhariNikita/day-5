"use strict";

var category = ["Electronics", "Clothing", "Books", "Groceries"];
var product = [
  {
    name: "shoes",
    price: "500",
    path: "https://rukminim2.flixcart.com/image/440/454/xif0q/shopsy-shoe/a/n/f/8-shopsy-rc07-8-cococart-full-white-original-imah5w64jacmgvth.jpeg?q=60",
  },
  {
    name: "short kurta",
    price: "300",
    path: "https://rukminim2.flixcart.com/image/440/454/xif0q/kurta/t/6/e/l-ds-002-wine-anzi-original-imah66pnrsn8x27b.jpeg?q=60",
  },
  {
    name: "kurta",
    price: "400",
    path: "https://rukminim2.flixcart.com/image/440/454/xif0q/kurta/p/3/s/xs-maro-3269-fashionpoint-original-imah5g6zfuvksjyx.jpeg?q=60",
  },
];

// shor circuit operator

category && category.length > 0 && category.forEach(function (v,i) {
    console.log(v,i);
    var listtag = document.createElement('li');
    console.log(listtag);
    document.querySelector("ul").append(listtag);
    listtag.innerHTML = v;
});

product && product.length > 0 && product.forEach(function (v, i) {
    console.log(v);
    var divtag = document.createElement('div');
    console.log(divtag);
    divtag.className = "col-xl-4 text-center";

    var imgtag = document.createElement("img");
    imgtag.className = 'img-fluid';
    var ptag = document.createElement("p");
    var h2tag = document.createElement("h2");

    imgtag.src = v.path;
    h2tag.innerHTML = v.price;
    ptag.innerHTML = v.name;

    divtag.append(imgtag, ptag, h2tag);
    document.getElementById('row').append(divtag);
});